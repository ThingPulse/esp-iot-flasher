# ESPGateway Ethernet LTE test firmware

Build: `pio run -e testbed-a7670`. See test/A7670_TESTBED.md.
This scoped source snapshot contains the LTE test app and its build dependencies.
