#pragma once

#include <stddef.h>
#include <string.h>

// Bounded, line-oriented parser: an embedded "OK" is never a terminal result.
class TestbedAtResponse {
 public:
  enum State { Waiting, Success, Error, Overflow };
  explicit TestbedAtResponse(const char* command) : command_(command) {}
  State feed(char c) {
    if (state != Waiting) return state;
    if (rawSize + 1 >= sizeof(raw)) return state = Overflow;
    raw[rawSize++] = c;
    raw[rawSize] = 0;
    if (c == '\r') return state;
    if (c != '\n') {
      if (lineSize + 1 >= sizeof(line)) return state = Overflow;
      line[lineSize++] = c;
      line[lineSize] = 0;
      return state;
    }
    if (!strcmp(line, "OK")) state = Success;
    else if (!strcmp(line, "ERROR") || !strncmp(line, "+CME ERROR", 10) ||
             !strncmp(line, "+CMS ERROR", 10)) state = Error;
    else if (lineSize && strcmp(line, command_) && strcmp(line, "RDY") &&
             strcmp(line, "PB DONE") && strcmp(line, "SMS DONE") &&
             strcmp(line, "Call Ready") && strcmp(line, "SMS Ready")) {
      // Only the solicited prefix (or a plain identity line) is a value.
      const char* value = line;
      if (line[0] == '+') {
        const char* colon = strchr(line, ':');
        size_t n = colon ? static_cast<size_t>(colon - line) : 0;
        if (!n || strncmp(command_, "AT+", 3) || strncmp(line, command_ + 2, n) ||
            (command_[n + 2] != '\0' && command_[n + 2] != '?' && command_[n + 2] != '=')) value = "";
        else {
          value = colon + 1;
          while (*value == ' ') ++value;
        }
      }
      if (*value && !payload[0]) {
        strncpy(payload, value, sizeof(payload) - 1);
      }
    }
    lineSize = 0;
    line[0] = 0;
    return state;
  }
  State state = Waiting;
  char raw[768] = {};
  char payload[256] = {};
 private:
  const char* command_;
  char line[256] = {};
  size_t lineSize = 0;
  size_t rawSize = 0;
};

inline bool testbedValidImei(const char* value) {
  if (strlen(value) != 15) return false;
  int sum = 0;
  bool nonzero = false;
  for (int i = 0; i < 15; ++i) {
    if (value[i] < '0' || value[i] > '9') return false;
    int n = value[i] - '0';
    nonzero |= n != 0;
    if (i % 2) { n *= 2; if (n > 9) n -= 9; }
    sum += n;
  }
  return nonzero && sum % 10 == 0;
}
