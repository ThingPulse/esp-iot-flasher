#pragma once
#include <stdio.h>
#include <string.h>

// HTTPACTION acknowledges first and reports the network result asynchronously.
// Neither OK alone nor an unrelated URC proves internet access.
struct TestbedHttpAction {
  char raw[768] = {};
  char line[128] = {};
  size_t used = 0, lineUsed = 0;
  bool acknowledged = false, received = false, failed = false;
  int method = -1, status = -1, bytes = -1;
  bool done() const { return failed || (acknowledged && received); }
  bool passed() const { return !failed && acknowledged && received && method == 0 && status == 204 && bytes == 0; }
  void feed(char c) {
    if (done()) return;
    if (used + 1 >= sizeof(raw)) { failed = true; return; }
    raw[used++] = c;
    if (c == '\r') return;
    if (c != '\n') {
      if (lineUsed + 1 >= sizeof(line)) { failed = true; return; }
      line[lineUsed++] = c;
      return;
    }
    if (!strcmp(line, "OK")) acknowledged = true;
    else if (!strcmp(line, "ERROR") || !strncmp(line, "+CME ERROR", 10)) failed = true;
    else if (!strncmp(line, "+HTTPACTION:", 12)) {
      char extra;
      received = sscanf(line, "+HTTPACTION: %d,%d,%d %c", &method, &status, &bytes, &extra) == 3;
      if (!received || method != 0 || status < 100 || bytes < 0) failed = true;
    }
    memset(line, 0, sizeof(line));
    lineUsed = 0;
  }
};
