#pragma once
#include <stdint.h>

// Access under the application's event-state lock. Never preserve a lease or
// negotiated parameters across a disconnect/reconnect cycle.
struct TestbedEthernetState {
  bool link = false;
  uint32_t ip = 0;
  uint16_t speedMbps = 0;
  bool duplexKnown = false;
  bool fullDuplex = false;

  void connected(uint16_t speed, bool known, bool full) {
    *this = TestbedEthernetState{};
    link = true;
    speedMbps = speed;
    duplexKnown = known;
    fullDuplex = known && full;
  }
  void gotIp(uint32_t address) { if (link) ip = address; }
  void disconnected() { *this = TestbedEthernetState{}; }
  bool ready() const { return link && ip != 0; }
};
