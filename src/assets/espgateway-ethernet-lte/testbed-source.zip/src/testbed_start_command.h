#pragma once

#include <ArduinoJson.h>
#include <stddef.h>
#include <ctype.h>

class TestbedStartCommand {
 public:
  bool feed(char c) {
    if (c == '\r') return false;
    if (c != '\n') {
      if (!overflow_) {
        if (size_ < sizeof(line_) - 1) line_[size_++] = c;
        else overflow_ = true;
      }
      return false;
    }
    line_[size_] = 0;
    StaticJsonDocument<256> doc;
    Reader reader{line_, size_, 0};
    bool start = !overflow_ && !deserializeJson(doc, reader) &&
                 doc["ST"].is<bool>() && doc["ST"].as<bool>();
    // ArduinoJson accepts trailing data by default; require a whole JSON line.
    while (reader.pos < size_) {
      if (!isspace(static_cast<unsigned char>(line_[reader.pos++]))) start = false;
    }
    size_ = 0;
    overflow_ = false;
    return start;
  }
 private:
  struct Reader {
    const char* text;
    size_t size;
    size_t pos;
    int read() { return pos < size ? static_cast<unsigned char>(text[pos++]) : -1; }
    size_t readBytes(char* buffer, size_t length) {
      size_t count = 0;
      while (count < length && pos < size) buffer[count++] = text[pos++];
      return count;
    }
  };
  char line_[128] = {};
  size_t size_ = 0;
  bool overflow_ = false;
};
