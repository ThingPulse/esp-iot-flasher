#pragma once

#include <ArduinoJson.h>
#include <stddef.h>
#include <ctype.h>
#include <initializer_list>

class TestbedStartCommand {
 public:
  enum Request { None = 0, Hardware = 1, Cellular, Capabilities, Invalid };
  char apn[64] = {};
  char url[201] = {};
  Request feed(char c) {
    if (c == '\r') return None;
    if (c != '\n') {
      if (!overflow_) {
        if (size_ < sizeof(line_) - 1) line_[size_++] = c;
        else overflow_ = true;
      }
      return None;
    }
    line_[size_] = 0;
    StaticJsonDocument<768> doc;
    Reader reader{line_, size_, 0};
    bool valid = !overflow_ && !deserializeJson(doc, reader);
    while (reader.pos < size_) {
      if (!isspace(static_cast<unsigned char>(line_[reader.pos++]))) valid = false;
    }
    Request request = None;
    if (valid && doc["CAP"].is<bool>() && doc["CAP"].as<bool>()) {
      request = doc.containsKey("ST") ? Invalid : Capabilities;
    } else if (valid && doc["ST"].is<bool>() && doc["ST"].as<bool>()) {
      if (doc.containsKey("CAP")) request = Invalid;
      else if (!doc.containsKey("testSet")) request = Hardware;
      else if (!doc["testSet"].is<const char*>()) request = Invalid;
      else if (!strcmp(doc["testSet"], "hardware")) request = Hardware;
      else if (!strcmp(doc["testSet"], "cellular")) {
        const char* a = doc["apn"] | "";
        const char* u = doc["url"] | "";
        bool safe = strlen(a) > 0 && strlen(a) < sizeof(apn) &&
                    strlen(u) < sizeof(url) &&
                    (!strncmp(u, "http://", 7) || !strncmp(u, "https://", 8));
        for (const char* v : {a, u}) {
          for (const char* c = v; *c; ++c)
            if (*c <= 32 || *c >= 127 || *c == '"' || *c == '\\') safe = false;
        }
        request = safe ? Cellular : Invalid;
        if (safe) { strcpy(apn, a); strcpy(url, u); }
      } else request = Invalid;
    }
    size_ = 0;
    overflow_ = false;
    return request;
  }
 private:
  struct Reader {
    const char* text;
    size_t size;
    size_t pos;
    int read() { return pos < size ? static_cast<unsigned char>(text[pos++]) : -1; }
    size_t readBytes(char* buffer, size_t length) {
      size_t count = 0;
      while (count < length && pos < size) buffer[count++] = text[pos++];
      return count;
    }
  };
  char line_[512] = {};
  size_t size_ = 0;
  bool overflow_ = false;
};
