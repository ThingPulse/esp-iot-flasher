#include <Arduino.h>
#include <ArduinoJson.h>
#include <WiFi.h>
#include <esp_ota_ops.h>
#include <esp_heap_caps.h>
#include <esp32/spiram.h>
#include "led.h"
#include "testbed_at_response.h"
#include "testbed_start_command.h"

#ifndef TESTBED_EXPECTED_MODEM_FW
#define TESTBED_EXPECTED_MODEM_FW ""
#endif

// Arduino 2.0.5 initializes and tests PSRAM before calling this function.
// GPIO16 is subsequently used for the Ethernet clock, making PSRAM inaccessible.
// Keep the boot memory test, but NEVER register that memory with the allocator.
// Merely moving the JSON buffer to internal RAM would leave other allocations
// and heap bookkeeping exposed to the same corrupted external heap.
extern "C" esp_err_t __wrap_esp_spiram_add_to_heapalloc() {
  return ESP_OK;
}

namespace {
HardwareSerial modem(1);
uint32_t psramSize, runNumber = 0;
bool psramBootTestPassed = false;
bool ethernetStarted = false;
bool synchronized = false;
TestbedStartCommand startCommand;

void row(JsonArray data, const char* name, const String& value, const char* result) {
  JsonObject item = data.createNestedObject();
  item["name"] = name;
  item["value"] = value;
  item["result"] = result;
}

// Bound draining even with a continuously noisy UART.
void drainModem() {
  uint32_t start = millis();
  while (millis() - start < 100) {
    for (int i = 0; i < 256 && modem.available(); ++i) modem.read();
    delay(1);
  }
}

TestbedAtResponse command(const char* text, uint32_t timeout = 3000) {
  drainModem();
  TestbedAtResponse response(text);
  modem.print(text);
  modem.print("\r\n");
  uint32_t start = millis();
  while (millis() - start < timeout) {
    for (int i = 0; i < 256 && modem.available(); ++i) {
      if (response.feed(modem.read()) != TestbedAtResponse::Waiting) return response;
    }
    delay(1);
  }
  return response;
}

uint32_t detectModem() {
  const uint32_t rates[] = {115200, 230400, 460800, 921600, 9600, 57600};
  uint32_t start = millis();
  while (millis() - start < 30000) {
    for (uint32_t rate : rates) {
      if (millis() - start >= 30000) break;
      modem.end();
      modem.setRxBufferSize(2048);
      modem.begin(rate, SERIAL_8N1, 13, 14);
      if (command("AT", 500).state == TestbedAtResponse::Success &&
          command("AT", 500).state == TestbedAtResponse::Success) return rate;
    }
  }
  return 0;
}

String evidence(const TestbedAtResponse& response) {
  const char* status = response.state == TestbedAtResponse::Success ? "OK" :
      response.state == TestbedAtResponse::Error ? "ERROR" :
      response.state == TestbedAtResponse::Overflow ? "OVERFLOW (truncated)" : "TIMEOUT";
  return String(status) + ": " + response.raw;
}

// A timeout loses transaction alignment. Do not let a delayed OK pass a later test.
struct QueryResult {
  String payload;
  bool ok;
};

QueryResult query(JsonArray data, const char* name, const char* at, bool required) {
  TestbedAtResponse response(at);
  if (!synchronized) {
    row(data, name, "Not run: modem communication unavailable", required ? "NOK" : "OK");
    return {"", false};
  }
  response = command(at);
  bool ok = response.state == TestbedAtResponse::Success && response.payload[0];
  row(data, name, evidence(response), required ? (ok ? "OK" : "NOK") : "OK");
  if (response.state == TestbedAtResponse::Waiting || response.state == TestbedAtResponse::Overflow)
    synchronized = false;
  return {String(response.payload), ok};
}

void runTests() {
  uint32_t start = millis();
  Serial.println("Starting ESPGateway Ethernet A7670G test");
  DynamicJsonDocument doc(24576);
  JsonArray data = doc.to<JsonArray>();
  row(data, "Mac Address", WiFi.macAddress(), "OK");
  row(data, "Test Suite", "espgateway-ethernet-a7670g/3", "OK");
  row(data, "Run Number", String(++runNumber), "OK");
  row(data, "Chip Model", ESP.getChipModel(), "OK");
  row(data, "Chip Revision", String(ESP.getChipRevision()), "OK");
  row(data, "Available Cores", String(ESP.getChipCores()), ESP.getChipCores() == 2 ? "OK" : "NOK");
  row(data, "Heap Size", String(ESP.getHeapSize()), ESP.getHeapSize() > 100000 ? "OK" : "NOK");
  row(data, "Free Heap", String(ESP.getFreeHeap()), ESP.getFreeHeap() > 100000 ? "OK" : "NOK");
  row(data, "PSRAM Size", String(psramSize), psramSize >= 4000000 ? "OK" : "NOK");
  row(data, "PSRAM Boot Test", psramBootTestPassed ? "Passed before Ethernet initialization" : "Initialization or memory test failed", psramBootTestPassed ? "OK" : "NOK");
  row(data, "PSRAM Runtime Use", "Disabled: GPIO16 is the Ethernet clock; all allocations use internal RAM", "OK");
  row(data, "Flash Chip Size", String(ESP.getFlashChipSize()), ESP.getFlashChipSize() >= 4000000 ? "OK" : "NOK");
  row(data, "Build Date", __DATE__, "OK");
  row(data, "Build Time", __TIME__, "OK");
  char sha[65];
  const esp_app_desc_t* app = esp_ota_get_app_description();
  for (int i = 0; i < 32; ++i) snprintf(sha + 2 * i, 3, "%02x", app->app_elf_sha256[i]);
  row(data, "Test Firmware ELF SHA256", sha, "OK");

  updateLed(0, CRGB::Yellow);
  uint32_t baud = detectModem();
  synchronized = baud != 0;
  row(data, "Modem AT", baud ? "Two AT commands returned OK" : "No AT response within startup window", baud ? "OK" : "NOK");
  row(data, "Modem UART Baud", String(baud), baud ? "OK" : "NOK");
  query(data, "Modem Manufacturer (AT+CGMI)", "AT+CGMI", true);
  auto model = query(data, "Modem Model (AT+CGMM)", "AT+CGMM", true);
  String modelName(model.payload);
  bool correctModel = model.ok &&
      (modelName == "A7670G" || modelName == "SIMCOM_A7670G" ||
       modelName == "A7670G-LLSE");
  row(data, "A7670G Identity", modelName, correctModel ? "OK" : "NOK");
  auto firmware = query(data, "Modem Firmware (AT+CGMR)", "AT+CGMR", true);
  const char* expected = TESTBED_EXPECTED_MODEM_FW;
  if (*expected) {
    row(data, "Modem Firmware Policy", String("Expected: ") + expected,
        firmware.ok && firmware.payload == expected ? "OK" : "NOK");
  } else {
    row(data, "Modem Firmware Policy", "Recorded only; no approved revision configured", "OK");
  }
  auto imei = query(data, "Modem IMEI (AT+CGSN)", "AT+CGSN", true);
  row(data, "Modem IMEI Format", imei.payload,
      imei.ok && testbedValidImei(imei.payload.c_str()) ? "OK" : "NOK");
  query(data, "Modem Identification (ATI)", "ATI", false);
  query(data, "Radio Functionality (AT+CFUN?)", "AT+CFUN?", false);
  query(data, "SIM Status (AT+CPIN?)", "AT+CPIN?", false);
  query(data, "SIM ICCID (AT+CICCID)", "AT+CICCID", false);
  query(data, "LTE Registration (AT+CEREG?)", "AT+CEREG?", false);
  query(data, "Operator (AT+COPS?)", "AT+COPS?", false);
  query(data, "Signal Quality (AT+CSQ)", "AT+CSQ", false);
  query(data, "Serving Cell (AT+CPSI?)", "AT+CPSI?", false);

  uint32_t ethStart = millis();
  while (ethernetStarted && (!ETH.linkUp() || !ETH.localIP()) && millis() - ethStart < ETH_TIMEOUT_MILLIS) delay(20);
  row(data, "ETH Initialization", ethernetStarted ? "true" : "false", ethernetStarted ? "OK" : "NOK");
  row(data, "ETH MAC Address", ETH.macAddress(), ethernetStarted && ETH.macAddress() != "00:00:00:00:00:00" ? "OK" : "NOK");
  row(data, "ETH Link", ETH.linkUp() ? "up" : "down", ETH.linkUp() ? "OK" : "NOK");
  row(data, "ETH Local IP", ETH.localIP().toString(), ETH.localIP() ? "OK" : "NOK");
  row(data, "ETH Full Duplex", ETH.fullDuplex() ? "true" : "false", ETH.fullDuplex() ? "OK" : "NOK");
  row(data, "ETH Link Speed", String(ETH.linkSpeed()) + " Mbps", ETH.linkSpeed() ? "OK" : "NOK");
  row(data, "Duration ms", String(millis() - start), "OK");
  bool passed = !doc.overflowed();
  for (JsonObject item : data) if (!strcmp(item["result"], "NOK")) passed = false;
  updateLed(0, passed ? CRGB::Green : CRGB::Red);
  // Never send a partial successful report on allocation failure.
  if (doc.overflowed()) {
    Serial.println("[{\"name\":\"Report Allocation\",\"value\":\"Report incomplete\",\"result\":\"NOK\"}]");
  } else {
    serializeJson(doc, Serial);
    Serial.println();
  }
  // Requests received during a run are duplicates, not queued new tests.
  while (Serial.available()) Serial.read();
}
}  // namespace

void setup() {
  Serial.begin(115200);
  psramBootTestPassed = psramFound();
  psramSize = psramBootTestPassed ? esp_spiram_get_size() : 0;
  // Fail safely if a future build loses the link-time wrapper. This check must
  // run while PSRAM is still accessible, before ETH.begin changes GPIO16.
  if (heap_caps_get_total_size(MALLOC_CAP_SPIRAM) != 0) {
    Serial.println("Unsafe testbed build: PSRAM registered as heap; Ethernet not started");
    while (true) delay(1000);
  }
  initStatusLeds();
  clearLeds();
  FastLED.show();
  WiFi.mode(WIFI_STA);
  ethernetStarted = ETH.begin(ETH_ADDR, ETH_POWER_PIN, ETH_MDC_PIN, ETH_MDIO_PIN,
                              ETH_TYPE, ETH_PHY_CLK_MODE, true);
  Serial.println("A7670G testbed ready; send {\"ST\":true}");
}

void loop() {
  while (Serial.available()) {
    if (startCommand.feed(Serial.read())) runTests();
  }
  delay(1);
}
