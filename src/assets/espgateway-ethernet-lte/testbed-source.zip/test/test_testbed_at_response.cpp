#include "../src/testbed_at_response.h"
#include <assert.h>
#include <stdio.h>

void feed(TestbedAtResponse& parser, const char* text) {
  while (*text) parser.feed(*text++);
}

int main() {
  TestbedAtResponse at("AT");
  feed(at, "AT\r\nBROKEN_OK\r\n");
  assert(at.state == TestbedAtResponse::Waiting);
  feed(at, "OK\r\n");
  assert(at.state == TestbedAtResponse::Success);

  TestbedAtResponse firmware("AT+CGMR");
  feed(firmware, "AT+CGMR\r\nRDY\r\n+CEREG: 1\r\n+CGMR: A123_A7670G\r\nOK\r\n");
  assert(firmware.state == TestbedAtResponse::Success);
  assert(!strcmp(firmware.payload, "A123_A7670G"));
  assert(strstr(firmware.raw, "+CEREG: 1"));

  TestbedAtResponse empty("AT+CGMR");
  feed(empty, "AT+CGMR\r\n+CEREG: 1\r\nOK\r\n");
  assert(!empty.payload[0]);
  TestbedAtResponse model("AT+CGMM");
  feed(model, "SIMCOM_A7670G\r\nOK\r\n");
  assert(!strcmp(model.payload, "SIMCOM_A7670G"));
  TestbedAtResponse error("AT+CPIN?");
  feed(error, "+CME ERROR: SIM not inserted\r\nOK\r\n");
  assert(error.state == TestbedAtResponse::Error);
  TestbedAtResponse plainError("AT");
  feed(plainError, "ERROR\r\n");
  assert(plainError.state == TestbedAtResponse::Error);
  TestbedAtResponse partial("AT");
  feed(partial, "\r\nO");
  assert(partial.state == TestbedAtResponse::Waiting);
  feed(partial, "K\r\n");
  assert(partial.state == TestbedAtResponse::Success);
  TestbedAtResponse overflow("AT");
  for (int i = 0; i < 300; ++i) overflow.feed('x');
  assert(overflow.state == TestbedAtResponse::Overflow);
  TestbedAtResponse rawOverflow("AT");
  for (int i = 0; i < 400; ++i) feed(rawOverflow, "\r\n");
  assert(rawOverflow.state == TestbedAtResponse::Overflow);
  assert(testbedValidImei("490154203237518"));
  assert(!testbedValidImei("490154203237519"));
  assert(!testbedValidImei("000000000000000"));
  assert(!testbedValidImei("49015420323751"));
  assert(!testbedValidImei("49015420323751x"));
  puts("Testbed AT parser and IMEI tests passed");
}
