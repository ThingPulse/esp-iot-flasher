#include "../src/testbed_ethernet_state.h"
#include <assert.h>
#include <stdio.h>

int main() {
  TestbedEthernetState state;
  assert(!state.ready() && !state.link);
  state.gotIp(123);
  assert(state.ip == 0); // Ignore an IP notification after disconnection.
  state.connected(100, true, true);
  assert(state.link && !state.ready() && state.fullDuplex);
  state.gotIp(123);
  assert(state.ready());
  auto snapshot = state;
  state.disconnected();
  assert(!state.link && state.ip == 0 && !state.duplexKnown && state.speedMbps == 0);
  assert(snapshot.ready() && snapshot.ip == 123); // One coherent report snapshot.
  state.connected(10, true, false);
  assert(state.ip == 0 && state.speedMbps == 10 && state.duplexKnown && !state.fullDuplex);
  state.connected(0, false, false); // Driver query failure must not look like 100/full.
  assert(!state.duplexKnown && state.speedMbps == 0 && !state.ready());
  puts("Ethernet state tests passed");
}
