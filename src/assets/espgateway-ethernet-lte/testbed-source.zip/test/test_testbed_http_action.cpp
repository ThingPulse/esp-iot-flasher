#include "../src/testbed_http_action.h"
#include <assert.h>
#include <initializer_list>
#include <stdio.h>
void feed(TestbedHttpAction& parser, const char* value) { while (*value) parser.feed(*value++); }
int main() {
  TestbedHttpAction valid;
  feed(valid, "AT+HTTPACTION=0\r\nOK\r\n+CEREG: 1\r\n");
  assert(!valid.done() && !valid.passed());
  feed(valid, "+HTTPACTION: 0,204,0\r\n");
  assert(valid.done() && valid.passed());
  TestbedHttpAction reversed;
  feed(reversed, "+HTTPACTION: 0,204,0\r\n");
  assert(!reversed.done());
  feed(reversed, "OK\r\n");
  assert(reversed.passed());
  for (const char* response : {"OK\n+HTTPACTION: 0,302,0\n", "OK\n+HTTPACTION: 0,200,12\n", "OK\n+HTTPACTION: 0,204,1\n", "ERROR\n", "OK\n+HTTPACTION: 0,204,0junk\n", "OK\n+HTTPACTION: 1,204,0\n"}) {
    TestbedHttpAction failure;
    feed(failure, response);
    assert(failure.done() && !failure.passed());
  }
  TestbedHttpAction overflow;
  for (int i = 0; i < 900; ++i) overflow.feed('x');
  assert(overflow.failed && !overflow.passed());
  puts("HTTP action tests passed");
}
