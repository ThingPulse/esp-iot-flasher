#include "../src/testbed_start_command.h"
#include <assert.h>
#include <stdio.h>

int feed(TestbedStartCommand& parser, const char* text) {
  int starts = 0;
  while (*text) starts += parser.feed(*text++);
  return starts;
}

int main() {
  TestbedStartCommand parser;
  assert(feed(parser, "{\"ST\":") == 0);
  assert(feed(parser, "true}\n") == 1);
  assert(feed(parser, "  {\"ST\": true} \r\n") == 1);
  assert(feed(parser, "{\"ST\":false}\n{\"ST\":1}\n{\"ST\":\"true\"}\n") == 0);
  assert(feed(parser, "{}\n[]\ntrue\nSELFTEST\n{invalid}\n") == 0);
  assert(feed(parser, "{\"ST\":true}junk\n{\"ST\":true}{}\n") == 0);
  for (int i = 0; i < 150; ++i) assert(!parser.feed(' '));
  assert(feed(parser, "{\"ST\":true}\n") == 0);
  assert(feed(parser, "{\"ST\":true}\n{\"ST\":true}\n") == 2);
  assert(feed(parser, "{\"ST\":true\n") == 0);
  assert(feed(parser, "{\"ST\":true}\n") == 1);
  puts("Testbed start command tests passed");
}
