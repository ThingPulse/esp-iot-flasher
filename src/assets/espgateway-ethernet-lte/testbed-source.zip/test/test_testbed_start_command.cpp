#include "../src/testbed_start_command.h"
#include <assert.h>
#include <stdio.h>

int feed(TestbedStartCommand& parser, const char* text) {
  int starts = 0;
  while (*text) starts += parser.feed(*text++);
  return starts;
}

int main() {
  TestbedStartCommand parser;
  assert(feed(parser, "{\"ST\":") == 0);
  assert(feed(parser, "true}\n") == 1);
  assert(feed(parser, "  {\"ST\": true} \r\n") == 1);
  assert(feed(parser, "{\"ST\":false}\n{\"ST\":1}\n{\"ST\":\"true\"}\n") == 0);
  assert(feed(parser, "{}\n[]\ntrue\nSELFTEST\n{invalid}\n") == 0);
  assert(feed(parser, "{\"ST\":true}junk\n{\"ST\":true}{}\n") == 0);
  for (int i = 0; i < 550; ++i) assert(!parser.feed(' '));
  assert(feed(parser, "{\"ST\":true}\n") == 0);
  assert(feed(parser, "{\"ST\":true}\n{\"ST\":true}\n") == 2);
  assert(feed(parser, "{\"ST\":true\n") == 0);
  assert(feed(parser, "{\"ST\":true}\n") == 1);
  assert(feed(parser, "{\"CAP\":true}\n") == TestbedStartCommand::Capabilities);
  assert(feed(parser, "{\"ST\":true,\"testSet\":\"hardware\"}\n") == TestbedStartCommand::Hardware);
  assert(feed(parser, "{\"ST\":true,\"testSet\":\"cellular\",\"apn\":\"internet\",\"url\":\"http://fixture.example/204\"}\n") == TestbedStartCommand::Cellular);
  assert(!strcmp(parser.apn, "internet"));
  assert(!strcmp(parser.url, "http://fixture.example/204"));
  assert(feed(parser, "{\"ST\":true,\"testSet\":\"cellular\"}\n") == TestbedStartCommand::Invalid);
  assert(feed(parser, "{\"ST\":true,\"testSet\":\"wrong\"}\n") == TestbedStartCommand::Invalid);
  assert(feed(parser, "{\"ST\":true,\"testSet\":true}\n") == TestbedStartCommand::Invalid);
  assert(feed(parser, "{\"ST\":true,\"CAP\":true}\n") == TestbedStartCommand::Invalid);
  assert(feed(parser, "{\"ST\":true,\"testSet\":\"cellular\",\"apn\":\"x\\rAT\",\"url\":\"http://fixture.example\"}\n") == TestbedStartCommand::Invalid);
  puts("Testbed start command tests passed");
}
