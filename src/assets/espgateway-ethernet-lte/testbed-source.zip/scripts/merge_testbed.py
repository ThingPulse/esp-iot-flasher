"""Produce the offset-zero image consumed by esp-iot-flasher for this environment."""
import os
import subprocess

Import("env")


def merge_testbed(source, target, env):
    build_dir = env.subst("$BUILD_DIR")
    platform = env.PioPlatform()
    esptool = os.path.join(platform.get_package_dir("tool-esptoolpy"), "esptool.py")
    boot_app = os.path.join(platform.get_package_dir("framework-arduinoespressif32"),
                            "tools", "partitions", "boot_app0.bin")
    subprocess.check_call([
        env.subst("$PYTHONEXE"), esptool, "--chip", "esp32", "merge_bin",
        # Preserve required address gaps, but do not pad the tail to flash size.
        "-o", os.path.join(build_dir, "app-firmware.bin"),
        "0x1000", os.path.join(build_dir, "bootloader.bin"),
        "0x8000", os.path.join(build_dir, "partitions.bin"),
        "0xe000", boot_app,
        "0x10000", os.path.join(build_dir, "firmware.bin"),
    ])


env.AddPostAction("$BUILD_DIR/${PROGNAME}.bin", merge_testbed)
